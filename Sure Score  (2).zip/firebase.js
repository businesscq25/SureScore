import { initializeApp }
from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

import {
getAuth,
GoogleAuthProvider,
signInWithPopup,
onAuthStateChanged,
signOut
}
from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const firebaseConfig = {

  apiKey: "AIzaSyAfO9NvXDahleQi3LlAUYNhgiL6ULYoIcM",

  authDomain: "sure-score-1462f.firebaseapp.com",

  projectId: "sure-score-1462f",

  storageBucket: "sure-score-1462f.firebasestorage.app",

  messagingSenderId: "871737403247",

  appId: "1:871737403247:web:f855e40fbccd26a8e7ea9a",

  measurementId: "G-SHCGJC40Z3"

};

const app =
initializeApp(firebaseConfig);

const auth = getAuth(app);

const provider =
new GoogleAuthProvider();

const loginBtn =
document.getElementById("loginBtn");

if(loginBtn){

loginBtn.addEventListener("click", ()=>{

signInWithPopup(auth, provider)

.then((result)=>{

const user = result.user;

localStorage.setItem(
"userName",
user.displayName
);

localStorage.setItem(
"userEmail",
user.email
);

location.reload();

});

});

}

const userName =
document.getElementById("userName");

const userEmail =
document.getElementById("userEmail");

onAuthStateChanged(auth, (user)=>{

if(user){

const allUserNames =
document.querySelectorAll("#userName");

allUserNames.forEach((element)=>{

element.innerText =
user.displayName;

});

if(userEmail){
userEmail.innerText =
user.email;
}

}

});

const logoutBtn =
document.getElementById("logoutBtn");

if(logoutBtn){

logoutBtn.addEventListener("click", ()=>{

signOut(auth)
.then(()=>{

localStorage.clear();

location.href =
"index.html";

});

});

}